context("test-aaa-documentation-helper")

skip("documentation helper tests not yet written")

test_that("warns user when column doesn't exist", {

})

test_that("no named arguments", {

})

test_that("only named arguments", {

})

test_that("mix of named arguments and logical switches", {

})
