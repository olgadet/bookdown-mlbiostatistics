This does a basic test to check that rpart.plot ported without problems.
For much more comprehensive tests, see rpart.plot/inst/slowtests.
