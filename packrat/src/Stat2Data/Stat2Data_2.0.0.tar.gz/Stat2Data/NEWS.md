# Stat2Data 2.0.0

** Many data sets have been added to support the second edition of the Stat2 text. 

** Several plotting functions have been added.



